##############################
## Model training from file ##
##############################

#Imports
########
import copy
import random 
import math

import tensorflow           as tf
import matplotlib.pyplot    as plt
import numpy                as np
import datetime             as dt


from scipy.stats      import norm

import os
import pickle

import keras
from keras.models import Sequential
from keras.layers import Dense,Dropout,Activation,Flatten
from keras.layers import Conv1D,MaxPooling1D,Conv2D,MaxPooling2D

# ResNet Imports 
from tensorflow import Tensor
from keras.layers import Input, Conv1D, ReLU, BatchNormalization, Add, AveragePooling1D, Flatten, Dense
from keras.models import Model

#from keras.utils  import plot_model
from keras.utils  import np_utils
from keras        import metrics
from keras        import regularizers

from keras import layers
import tensorflow_addons as tfa

import keras.backend as k

### COLAB
###
# from google.colab     import drive
# 
# drive.mount('/content/drive')

## Enter data location here
data_dir = "INSERT HERE"
output_dir = "INSERT HERE"

# Timestamp and Storage:
########################
startdate = dt.datetime.now()
timestamp = startdate.strftime('%d%m_%H%M%S')
# dataname  = "cifar10"
dataname  = "cifar100"
# dataname  = "imagenette"
# transform = "Hilbert"
transform = "Dotprint" 
modelname = "ViT"
dirname   = dataname + "_" + transform
filename  = dirname + ".dat"

os.chdir(output_dir)
os.mkdir(modelname + "_" + dirname + "_" + timestamp)
os.chdir(modelname + "_" + dirname + "_" + timestamp)

# Figure Formatting:
####################
figure_size = (17.5,8)

# font sizes
fs = 20 #fontsize
ts = 25 #titlesize
ls = 15 #legendsize
tick_size = 15

# visual settings
ms = 10
lw = 2

# Markers and linetypes
my_markers = ['o','v','>','<','^','s','+','x','p','h']
line_styles = ["solid","dashed","dotted","dashdot"]

## Dataload
###########

with (open(data_dir+"/cifar10_Dotprint_Augmentation_0.dat","rb")) as data_source:
    loaded_data = pickle.load(data_source)
    data_source.close()

print("Working on augmented data")
print(loaded_data.keys())

x_train = loaded_data["Training"]["Data"][transform]
y_train = loaded_data["Training"]["Label"]
y_train_arg = [np.argmax(element) for element in y_train]
x_test = loaded_data["Validation"]["Data"][transform]
y_test = loaded_data["Validation"]["Label"]
y_test_arg = [np.argmax(element) for element in y_test]

del(loaded_data)

input_shape = x_train.shape
if dataname == 'cifar10':
    class_labels = ["airplane","car","bird","cat","deer","dog","frog","horse","ship","truck"] 
    nb_classes = len(class_labels)
elif dataname == 'cifar100':
    class_labels = [
    'apple','aquarium_fish','baby','bear','beaver','bed','bee','beetle','bicycle','bottle','bowl','boy','bridge','bus','butterfly','camel','can','castle','caterpillar','cattle','chair','chimpanzee','clock','cloud','cockroach','couch','crab','crocodile','cup',
    'dinosaur','dolphin','elephant','flatfish','forest','fox','girl','hamster','house','kangaroo','computer_keyboard','lamp','lawn_mower','leopard','lion','lizard','lobster','man','maple_tree','motorcycle','mountain','mouse','mushroom',
    'oak_tree','orange','orchid','otter','palm_tree','pear','pickup_truck','pine_tree','plain','plate','poppy','porcupine','possum','rabbit','raccoon','ray','road','rocket','rose','sea','seal','shark','shrew','skunk','skyscraper','snail','snake',
    'spider','squirrel','streetcar','sunflower','sweet_pepper','table','tank','telephone','television','tiger','tractor','train','trout','tulip','turtle','wardrobe','whale','willow_tree','wolf','woman','worm',
    ]
    nb_classes = len(class_labels)
elif dataname == 'imagenette':
    class_labels =['tench','English springer','cassette player','chain saw','church','French horn','garbage truck','gas pump','golf ball','parachute']
    nb_classes = len(class_labels)

## Model Definition
###################
input_shape_1d = input_shape[1:]

## Setting labels to categorical variables
y_train = np_utils.to_categorical(y_train,nb_classes)
y_test = np_utils.to_categorical(y_test,nb_classes)


kernel_size = 16 # [9, 16, 25, 36]

image_size = input_shape[1]  # We'll resize input images to this size
patch_size = kernel_size  # Size of the patches to be extracted from the linearized input image
num_patches = image_size // patch_size

# projection_dim = 16
projection_dim = patch_size*3 # Nb channels per pixel and patches
num_heads = 4
transformer_units = [
    projection_dim * 2,
    projection_dim,
]  # Size of the transformer layers
transformer_layers = 8
mlp_head_units = [2048, 1024]  # Size of the dense layers of the final classifier

# optimizer  = 'adam'
activation = 'relu'
my_loss    = 'categorical_crossentropy'
learning_rate = 0.0001
weight_decay  = 0.0001
mystride   = 1

## Data transformation for transformer
######################################
# resized_image = tf.image.resize(
#     tf.convert_to_tensor([image]), size=(image_size, image_size)
# )
data_augmentation = keras.Sequential(
    [
        layers.Normalization(),
        layers.Reshape(input_shape_1d, input_shape=input_shape_1d)
    ],
    name="data_augmentation",
)

data_augmentation.layers[0].adapt(x_train)
print(x_train.shape)

## Vision Tranformer:
#####################

def mlp(x, hidden_units, dropout_rate):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    return x

class Patch(layers.Layer):
    def __init__(self, patch_size):
        super().__init__()
        self.patch_size = patch_size
        
    def call(self, images):
        images = tf.convert_to_tensor(images)
        sample_size = tf.shape(images)[0]
        patches = tf.reshape(images, (sample_size, num_patches, self.patch_size*3))
        return patches

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim):
        super().__init__()
        self.num_patches = num_patches
        self.projection = layers.Dense(units=projection_dim)
        # self.position_embedding = layers.Embedding(
        #     input_dim=num_patches, output_dim=projection_dim
        # )

    def call(self, patch):
        # positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patch) #  + self.position_embedding(positions)
        return encoded

def create_vit_classifier(batch_size):
    inputs = layers.Input(shape=input_shape_1d)
    # Augmented data
    augmented = data_augmentation(inputs)
    # Create patches.
    patches = Patch(patch_size)(augmented)
    # Encode images.
    encoded_patches = PatchEncoder(num_patches, projection_dim)(patches)

    # Create multiple layers of the Transformer block.
    for _ in range(transformer_layers):
        # Layer normalization 1.
        x1 = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
        # Create a multi-head attention layer.
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads,
            key_dim=projection_dim,
            kernel_regularizer=regularizers.l2(0.01),
            bias_regularizer=regularizers.l2(0.01),
            dropout=0.1
        )(x1, x1)
        # Skip connection 1.
        x2 = layers.Add()([attention_output, encoded_patches])
        # Layer normalization 2.
        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        # MLP.
        x3 = mlp(x3, hidden_units=transformer_units, dropout_rate=0.1)
        # Skip connection 2.
        encoded_patches = layers.Add()([x3, x2])
        # inputs = layers.Add()([x3, x2])

    # Create a [batch_size, projection_dim] tensor.
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation = layers.Flatten()(representation)
    representation = layers.Dropout(0.5)(representation)
    # Add MLP.
    features = mlp(representation, hidden_units=mlp_head_units, dropout_rate=0.5)
    # Classify outputs.
    output = layers.Dense(nb_classes, activation = 'softmax')(features)
    # Create the Keras model.
    model = keras.Model(inputs=inputs, outputs=output)
    return model

def run_experiment(model, batch_size, epochs):
    model.compile(
        optimizer='adam',
        # loss='sparse_categorical_crossentropy',
        loss=keras.losses.CategoricalCrossentropy(from_logits=False),
        metrics=['accuracy','top_k_categorical_accuracy']
    )
    print("Model compilation completed")

    checkpoint_filepath = "/tmp/checkpoint"
    checkpoint_callback = keras.callbacks.ModelCheckpoint(
        checkpoint_filepath,
        monitor="val_accuracy",
        save_best_only=True,
        save_weights_only=True,
    )
    print("Checkpoint created")

    history = model.fit(
        x=x_train,
        y=y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=0.1,
        verbose = 0,
        callbacks=[checkpoint_callback],
    )
    print("Model fit completed")

    return history

## Hyperparameters
##################
nb_epoch = 150  #40 too fast convergence to check the details. 
nb_batch = [20, 64, 128] # [25, 50, 100, 200] # [64, 128, 256, 512]
nb_runs = 5


## Model Training
#################

total_runs = len(nb_batch)*nb_runs
run_counter = 0
    
for my_batch in nb_batch:
    modelstart = dt.datetime.now()
    for i in range(nb_runs):
        run_start = dt.datetime.now()
        my_features = {}
        my_features["Hyperparameters"] = {"Epochs": nb_epoch, "Batch": my_batch, "run": i, "lr": learning_rate, "Data": dataname, "Transformation": transform, "kernel_size": kernel_size, "Model": modelname}
        
        print("Running models: %.2f" %(run_counter/total_runs*100),"%")
        mymodel = create_vit_classifier(my_batch)
        history = run_experiment(mymodel, my_batch, nb_epoch)

        my_features["train_accuracy"] = history.history['accuracy']
        my_features["train_loss"] = history.history['loss']
        my_features["val_accuracy"] = history.history['val_accuracy']
        my_features["val_loss"] = history.history['val_loss']
        
        #_, accuracy = mymodel.evaluate(x_test, y_test)
        #print(f"Test accuracy: {round(accuracy * 100, 2)}%")
        #
        #my_features["test_accuracy"] = accuracy
        
        _, accuracy, top_5_accuracy = mymodel.evaluate(x_test, y_test)
        print(f"Test accuracy: {round(accuracy * 100, 2)}%")
        print(f"Test top 5 accuracy: {round(top_5_accuracy * 100, 2)}%")
        
        my_features["test_accuracy"] = accuracy
        my_features["test_top_5_accuracy"] = top_5_accuracy
                
        k.clear_session()
        del(mymodel)
        del(history)

        ## Store Training Features
        with (open("Features_%i.dat" %run_counter,"wb")) as my_file:
            pickle.dump(my_features,my_file,protocol=pickle.HIGHEST_PROTOCOL)
            my_file.close()
        del(my_features)
        run_counter += 1
