!pip install -U tensorflow-addons

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow_addons as tfa

# COLAB
#
from google.colab     import drive
import os
import datetime as dt
import pickle
import numpy as np

import keras.backend as k

## INSERT YOUR data locations here:
data_dir = "INSERT HERE"
output_dir = "INSERT HERE"
## COLAB
drive.mount('/content/drive')
os.chdir(data_dir)

## Cluster:

# Timestamp and Storage:
########################
startdate = dt.datetime.now()
timestamp = startdate.strftime('%d%m_%H%M%S')
# dataname  = "cifar10"
dataname  = "cifar100"
# dataname  = "imagenette"
transform = "ViT_2D"
# transform = "Dotprint" 
modelname = "ViT_2D"
dirname   = dataname + "_" + transform
filename  = dirname + ".dat"

num_classes = 100
input_shape = (32, 32, 3)

## Online data 
# (x_train, y_train), (x_test, y_test) = keras.datasets.cifar100.load_data()

# Colab
# Load data from file:
with (open(dataname+"_2D.dat","rb")) as handle:
    my_data = pickle.load(handle)
    handle.close()


## COLAB
os.mkdir(modelname + "_" + dirname + "_" + timestamp)
os.chdir(modelname + "_" + dirname + "_" + timestamp)

x_train = my_data["x_train"]
y_train = my_data["y_train"]
x_test  = my_data["x_test"]
y_test  = my_data["y_test"]

nb_classes = y_train.shape[1]
input_shape = x_train.shape[1:]

print(f"x_train shape: {x_train.shape} - y_train shape: {y_train.shape}")
print(f"x_test shape: {x_test.shape} - y_test shape: {y_test.shape}")

# Hyperparameters
learning_rate = 0.0001
weight_decay = 0.0001
nb_batch = [10,20]
nb_runs = 5
nb_epochs = 150
image_size = 64  # We'll resize input images to this size
patch_size = 8  # Size of the patches to be extract from the input images
num_patches = (image_size // patch_size) ** 2
kernel_size = patch_size**2

# projection_dim = 64
projection_dim = 3*(patch_size**2)
num_heads = 4
transformer_units = [
    projection_dim * 2,
    projection_dim,
]  # Size of the transformer layers
transformer_layers = 8
mlp_head_units = [2048, 1024]  # Size of the dense layers of the final classifier

# Data Augmentation
data_augmentation = keras.Sequential(
    [
        layers.Normalization(),
        layers.Resizing(image_size, image_size),
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(factor=0.02),
        layers.RandomZoom(
            height_factor=0.2, width_factor=0.2
        ),
    ],
    name="data_augmentation",
)
# Compute the mean and the variance of the training data for normalization.
data_augmentation.layers[0].adapt(x_train)

# Multilayer percenptron

def mlp(x, hidden_units, dropout_rate):
    for units in hidden_units:
        x = layers.Dense(units, activation=tf.nn.gelu)(x)
        x = layers.Dropout(dropout_rate)(x)
    return x

# Patch creation

class Patches(layers.Layer):
    def __init__(self, patch_size):
        super().__init__()
        self.patch_size = patch_size

    def call(self, images):
        batch_size = tf.shape(images)[0]
        # print("Batch size is: ", batch_size)
        patches = tf.image.extract_patches(
            images=images,
            sizes=[1, self.patch_size, self.patch_size, 1],
            strides=[1, self.patch_size, self.patch_size, 1],
            rates=[1, 1, 1, 1],
            padding="VALID",
        )
        # print("First patches have shape: ", patches.shape)
        patch_dims = patches.shape[-1]
        # print("Patches have dimensions before reshape:", patch_dims)
        patches = tf.reshape(patches, [batch_size, -1, patch_dims])
        return patches

# Patch encoding

class PatchEncoder(layers.Layer):
    def __init__(self, num_patches, projection_dim):
        super().__init__()
        self.num_patches = num_patches
        self.projection = layers.Dense(units=projection_dim)
        self.position_embedding = layers.Embedding(
            input_dim=num_patches, output_dim=projection_dim
        )

    def call(self, patch):
        positions = tf.range(start=0, limit=self.num_patches, delta=1)
        encoded = self.projection(patch) + self.position_embedding(positions)
        return encoded

# Built ViT

def create_vit_classifier():
    inputs = layers.Input(shape=input_shape)
    # Augment data.
    augmented = data_augmentation(inputs)
    # Create patches.
    patches = Patches(patch_size)(augmented)
    # Encode patches.
    encoded_patches = PatchEncoder(num_patches, projection_dim)(patches)

    # Create multiple layers of the Transformer block.
    for _ in range(transformer_layers):
        # Layer normalization 1.
        x1 = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
        # Create a multi-head attention layer.
        attention_output = layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=projection_dim, dropout=0.1
        )(x1, x1)
        # Skip connection 1.
        x2 = layers.Add()([attention_output, encoded_patches])
        # Layer normalization 2.
        x3 = layers.LayerNormalization(epsilon=1e-6)(x2)
        # MLP.
        x3 = mlp(x3, hidden_units=transformer_units, dropout_rate=0.1)
        # Skip connection 2.
        encoded_patches = layers.Add()([x3, x2])

    # Create a [batch_size, projection_dim] tensor.
    representation = layers.LayerNormalization(epsilon=1e-6)(encoded_patches)
    representation = layers.Flatten()(representation)
    representation = layers.Dropout(0.5)(representation)
    # Add MLP.
    features = mlp(representation, hidden_units=mlp_head_units, dropout_rate=0.5)
    # Classify outputs.
    # logits = layers.Dense(num_classes)(features)
    output = layers.Dense(nb_classes, activation = 'softmax')(features)
    # Create the Keras model.
    model = keras.Model(inputs=inputs, outputs=output)
    return model

# Compile, train and evaluate model

def run_experiment(model, batch_size):
    optimizer = tfa.optimizers.AdamW(
        learning_rate=learning_rate, weight_decay=weight_decay
    )

    model.compile(
        optimizer=optimizer,
        # loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        loss=keras.losses.CategoricalCrossentropy(from_logits=False),
        metrics=['accuracy','top_k_categorical_accuracy']
        # metrics=[
        #     keras.metrics.SparseCategoricalAccuracy(name="accuracy"),
        #     keras.metrics.SparseTopKCategoricalAccuracy(5, name="top-5-accuracy"),
        # ],
    )

    checkpoint_filepath = "/tmp/checkpoint"
    checkpoint_callback = keras.callbacks.ModelCheckpoint(
        checkpoint_filepath,
        monitor="val_accuracy",
        save_best_only=True,
        save_weights_only=True,
    )

    history = model.fit(
        x=x_train,
        y=y_train,
        batch_size=batch_size,
        epochs=nb_epochs,
        validation_split=0.1,
        callbacks=[checkpoint_callback],
    )

     #model.load_weights(checkpoint_filepath)
    
    return history


run_counter = 0
total_runs = len(nb_batch)*nb_runs

for my_batch in nb_batch:
    for my_run in range(nb_runs):
        my_features = {}
        my_features["Hyperparameters"] = {"Epochs": nb_epochs, "Batch": my_batch, "run": my_run, "lr": learning_rate, "Data": dataname, "Transformation": transform, "kernel_size": kernel_size}
        
        print("Running models: %.2f" %(run_counter/total_runs*100),"%")
        mymodel = create_vit_classifier()
        history = run_experiment(mymodel, my_batch)

        my_features["train_accuracy"] = history.history['accuracy']
        my_features["train_loss"] = history.history['loss']
        my_features["val_accuracy"] = history.history['val_accuracy']
        my_features["val_loss"] = history.history['val_loss']
        
        #_, accuracy = mymodel.evaluate(x_test, y_test)
        #print(f"Test accuracy: {round(accuracy * 100, 2)}%")
        _, accuracy, top_5_accuracy = mymodel.evaluate(x_test, y_test)
        print(f"Test accuracy: {round(accuracy * 100, 2)}%")
        print(f"Test top 5 accuracy: {round(top_5_accuracy * 100, 2)}%")

        my_features["test_accuracy"] = accuracy
        my_features["test_top_5_accuracy"] = top_5_accuracy

        k.clear_session()
        del(mymodel)
        del(history)

        ## Store Training Features
        with (open("Features_%i.dat" %run_counter,"wb")) as my_file:
            pickle.dump(my_features,my_file,protocol=pickle.HIGHEST_PROTOCOL)
            my_file.close()
        del(my_features)
        run_counter += 1