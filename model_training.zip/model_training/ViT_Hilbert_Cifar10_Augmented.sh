#!/bin/bash
#SBATCH --job-name=ViT_H_C10_A_Short
#SBATCH --time=00-72:00
#SBATCH --nodes=1
#SBATCH --gpus-per-node=1
#SBATCH --cpus-per-gpu=1
#SBATCH --mem-per-gpu=100G
#SBATCH --mail-user=bert.verbruggen@vub.be
#SBATCH --mail-type=ALL
#SBATCH --output ViT_Hilbert_C10_Aug_short.log
#SBATCH -p ampere_gpu

module load TensorFlow/2.7.1-foss-2021b-CUDA-11.4.1
module load tensorflow_addons/0.15.0-foss-2021b-CUDA-11.4.1
# module load keras/2.7.0
module load SciPy-bundle/2021.10-foss-2021b
module load matplotlib/3.4.3-foss-2021b

python "ViT_Hilbert_Cifar10_Augmented.py"
